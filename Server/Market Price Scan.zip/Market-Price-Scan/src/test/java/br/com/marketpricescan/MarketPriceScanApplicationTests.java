package br.com.marketpricescan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketPriceScanApplicationTests {

	@Test
	void contextLoads() {
	}

}
